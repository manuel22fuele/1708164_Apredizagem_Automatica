import pandas as pd
import numpy as np
from sklearn import neighbors
from sklearn.model_selection import train_test_split

# Leitura do dataset "Dry_Bean_Dataset" a partir do link e armazenando-o na variavél 'df'
df=pd.read_csv("https://raw.githubusercontent.com/Fer412/Datasets-2023/main/Dry_Bean_Dataset.csv",sep=';', header=0, decimal=',')
# Transformando o csv em um array numpy
df=np.array(df)

X=df[:,:16]
y=df[:,16:].T[0]

X_train, X_test, y_train, y_test = train_test_split(X, y, stratify=y, test_size=0.20,random_state=42 )
knc = neighbors.KNeighborsClassifier(n_neighbors=7, weights="uniform")
knc.fit(X_train,y_train)
print("knc_score(train/teste) =", knc.score(X_test, y_test))